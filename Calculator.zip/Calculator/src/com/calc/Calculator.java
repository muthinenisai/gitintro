package com.calc;

import java.util.Scanner;
import java.math.*;

public class Calculator {

	public static void main(String[] args) {

		// Declaring two variables
		int num1, num2;

		// an output statement to display message
		System.out.println(" Basic Calculator Operations Are:");
		System.out.println(" ");

		// displaying basic Arithmetic operations
		System.out.println("1. Add\n2. Substraction\n3. Multiplication\n4. Division\n5. Modules:");
		System.out.println(" ");

		System.out.println("Choose Operator:");
		System.out.println(" ");

		// taking user inputs by using scanner
		Scanner sc = new Scanner(System.in);

		// taking user input operators
		int Operator = sc.nextInt();

		// using scanner taking two inputs
		System.out.println("Enter first number:");
		num1 = sc.nextInt();
		System.out.println("Enter second number:");
		num2 = sc.nextInt();

		int result = 0;

		// using switch to operates on the basis of Operator values
		switch (Operator) {

		case 1:

			result = num1 + num2;
			break;

		case 2:

			result = num1 - num2;
			break;

		case 3:

			result = num1 * num2;
			break;

		case 4:

			result = num1 / num2;
			break;
		case 5:

			result = num1 % num2;
			break;

		// if user choose any wrong operators
		default:

			System.out.println("Sorry ! you have choosed wrong Operator");
          
		}

		// And printing the final result
		System.out.println("Final Result is " + result);
	}

}
